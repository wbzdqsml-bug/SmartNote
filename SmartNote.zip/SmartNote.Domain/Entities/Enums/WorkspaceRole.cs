﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartNote.Domain.Entities.Enums
{
    public enum WorkspaceRole { Owner = 0, Admin = 1, Member = 2, Viewer = 3 }
}
