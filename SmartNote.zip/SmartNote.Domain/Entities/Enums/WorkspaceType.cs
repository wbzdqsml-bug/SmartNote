﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SmartNote.Domain.Entities.Enums
{
    public enum WorkspaceType { Personal = 0, Team = 1 }
}
