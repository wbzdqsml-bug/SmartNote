﻿namespace SmartNote.WebAPI.Admin.Config
{
    public class JwtConfig
    {
    }
}
