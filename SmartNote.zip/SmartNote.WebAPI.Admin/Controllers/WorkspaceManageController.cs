﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace SmartNote.WebAPI.Admin.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WorkspaceManageController : ControllerBase
    {
    }
}
