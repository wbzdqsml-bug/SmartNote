﻿namespace SmartNote.WebAPI.Admin.Filters
{
    public class ValidationFilter
    {
    }
}
