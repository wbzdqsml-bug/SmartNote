﻿namespace SmartNote.WebAPI.Admin.Middlewares
{
    public class RequestLoggingMiddleware
    {
    }
}
