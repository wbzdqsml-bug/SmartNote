﻿namespace SmartNote.WebAPI.User.Config
{
    public class JwtConfig
    {
    }
}
