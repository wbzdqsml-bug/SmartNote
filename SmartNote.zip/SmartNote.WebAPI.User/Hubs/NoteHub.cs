﻿namespace SmartNote.WebAPI.User.Hubs
{
    public class NoteHub
    {
    }
}
